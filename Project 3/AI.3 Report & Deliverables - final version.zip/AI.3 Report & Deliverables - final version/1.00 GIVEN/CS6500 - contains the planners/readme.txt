To run a planner:

<planner-name> -o <domain> -f <problem>

For example,

Linux:   ./blackbox -o domain.pddl -f prob01.pddl
Windows: blackbox -o domain.pddl -f prob01.pddl

Sorry there is no windows executable for sgplan522
